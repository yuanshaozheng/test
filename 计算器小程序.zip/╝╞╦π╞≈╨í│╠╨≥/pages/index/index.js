//index.js
Page({
  data: {
    num: '123',
    op: '+'
  },
  result: null,
  isclear: false,
  numBtn: function(e) {
    var num = e.target.dataset.val
    // console.log(num)
    if (this.data.num==='0' || this.isclear) {
      this.setData({
        num: num
      })
      this.isclear = false
    } else {
      this.setData({
        num: this.data.num + num
      })
    }
    console.log(this.data.num)
  },
  opBtn: function(e) {
    // 顺序
    var op = this.data.op
    var num = Number(this.data.num)
    console.log(op)
    console.log(num)
    this.setData({
      // 顺序
      op: e.target.dataset.val
    })
    if(this.isclear){
      return
    }
    this.isclear = true
    if (this.result === null) {
      this.result = num
      return
    }
    
    if (op === '+') {
      this.result = this.result + num
    }else if(op === "-"){
      this.result = this.result - num
    }else if(op =='*'){
      this.result = this.result * num
    }else if(op =='/'){
      this.result = this.result / num
    }else if(op =='%'){
      this.result = this.result % num
    }
    console.log(this.result)
    this.setData({
      num: this.result
    })

  },
  dotBtn:function(e){
    var f = e.target.dataset.val
    this.setData({num:this.data.num+'.'})
  },
  delBtn:function(){
    var num = this.data.num.substr(0,this.data.num.length -1)
    // console.log(num)
    
    this.setData({num:num===''?'0':num})
  },
  resetBtn:function(){
    this.result = null
    this.isclear = false
    this.setData({num:'0',op:''})
  }
})