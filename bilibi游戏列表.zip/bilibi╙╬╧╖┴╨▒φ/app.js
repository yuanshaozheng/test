//app.js
App({
  onLaunch: function () {
    var that = this
    wx.getSetting({   
      success(res){
        console.log(333)
        
        
        if(res.authSetting['scope.userInfo']){
          wx.getUserInfo({
            success(res){
              console.log(res.userInfo)
              that.globalData.userInfo = res.userInfo
              if(that.getshow){
                that.getshow(res)
              }
              
              
            }
          })
        }
      }
    })
    
    
  },
  globalData: {
    userInfo: null
  }
})