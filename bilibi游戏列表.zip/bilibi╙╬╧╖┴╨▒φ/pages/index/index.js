//index.js
//获取应用实例
const app = getApp()
Page({
  data: {
    message: [],
    page:0
  },
  //事件处理函数
  onLoad: function() {
    var that = this
    this.getmessage(that.data.page)
  
  },
  get_video_info() {
    console.log(111)
  },
  dingyue() {
    // wx.showModal({
    //   title: '',
    //   content: '订阅成功',
    //   showCancel:false
    // })
    wx.showToast({
      title: '订阅成功',
    })
  },
  getmessage(page){
    var that = this
    if(page==5){
      page=0,
      that.setData({
        page:page+1
      })
    }
    if(page==0){
      wx.showLoading({
        title: '加载中',
      })    
    }
    wx.request({
      url: "https://www.fastmock.site/mock/93050931fc378580abc0df19d5abffaa/video/api" + page,
      success(res) {
        if(that.data.page>0){
          var messagetemp = that.data.message
          that.setData({
            message: messagetemp.concat(res.data.data.items),
            page:page+1
          })
          // console.log(res)
        }else{
          that.setData({
            message: res.data.data.items,
            page:page+1
          })
        }     
      },
      complete() {
        wx.hideLoading()
      }
    })
  },
  onReachBottom() {
    var that = this
    wx.showLoading({
      title: '加载更多',
    })
    this.getmessage(that.data.page)
  }
})
