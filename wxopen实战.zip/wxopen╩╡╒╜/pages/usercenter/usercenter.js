// // 一一一一一一一

// // pages/usercenter/usercenter.js
// Page({

//   data: {
//     openid:"",
//     resres:""
//   },
//   onLoad: function (options) {
//     var app = getApp();
//     // var openid = app.globalData.openid
//     // console.log(app.globalData.openid)
//     // console.log(11)
//     // this.setData({
//     //   openid:app.globalData.openid
//     // })
//     var that = this;
//     // 第一次出不来
//     // console.log(wx.getStorageSync('openid'))
 
  
//     app.getOpenid().then(function (res) {
//       console.log(res)
      
//       that.setData({
//         openid: wx.getStorageSync('openid'),
//         resres: JSON.stringify(wx.getStorageSync('resres'))
//       })
//       console.log(res.data);

//     });
//   }
// })


// 二二二二二二二
// pages/usercenter/usercenter.js
Page({
  data: {
    openid: "",
    resres:""
  },
  onLoad: function (options) {
    var app = getApp();
    var that = this;
    app.getOpenid()
    app.getshow = res => {
      that.setData({
        openid: res.data.openid,
        resres: JSON.stringify(res)
      })
      console.log(that.data.openid)
    }
  }
})