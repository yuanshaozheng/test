// //app.js  一一一一一一一二一
// App({
//   onLaunch: function() {
//   },
//   getOpenid() {
//     var that = this
//     return new Promise(function (resolve, reject) {
//     // 登录
//     wx.login({
//       success(res) {
//         if (res.code) {
//           console.log("hsd")
//           // console.log(res)
//           wx.request({
//             url: 'https://api.weixin.qq.com/sns/jscode2session?appid=' + 'wxa23f235d51bcfa2c' + '&secret=' + 'f33f7a5a46a244fce0902478b63d8b01' + '&js_code=' + res.code + '&grant_type=authorization_code',
//             success(res) {
//               wx.setStorageSync('openid', res.data.openid)
//               wx.setStorageSync("resres", res)
//               resolve(res);
//               // console.log(res)
//               // 可以不存storage
//               // wx.setStorage({
//               //   key: 'openid',
//               //   data: res.data.openid,
//               // })
//               // that.globalData.openid = res.data.openid
//               // console.log(that.globalData.openid)
//             }
//           })
//         } else {
//           console.log("登陆失败" + res.data.errMsg)
//           reject("error")
//         }
//         // 发送 res.code 到后台换取 openId, sessionKey, unionId
//       }
//     })
//     })


//   },
//   globalData: {
//     openid: ''
//   }
// })



//app.js 二二二二二二二二二一二
App({
  onLaunch: function () {
    // 展示本地存储能力

  },
  getOpenid() {
    var that = this
    // 登录
    wx.login({
      success(res) {
        if (res.code) {
          console.log("hsd")
          wx.request({
            url: 'https://api.weixin.qq.com/sns/jscode2session?appid=' + 'wxa23f235d51bcfa2c' + '&secret=' + 'f33f7a5a46a244fce0902478b63d8b01' + '&js_code=' + res.code + '&grant_type=authorization_code',
            success(res) {
              console.log(res)
              that.getshow(res)

            }
          })
        } else {
          console.log("登陆失败" + res.data.errMsg)
        }

      }
    })
  },
  globalData: {
    openid: ''
  }
})