Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentIndexNav:0,
    videoList:[],
    navList:[],
    swiperList:[],
    value:"aaa",
    show(){
      
      console.log(this.value)
    }
    
  },
  activeNav:function(e){
    // console.log(123)
    this.setData({
      currentIndexNav:e.target.dataset.id
    })
    // console.log(e.target.dataset.id)
    

  },
  getSwiperList(){
    let that = this
    wx.request({
      url: 'https://www.fastmock.site/mock/93050931fc378580abc0df19d5abffaa/video/api.bili_swiper',
      success(res){
        console.log(res)
        if(res.data.code===0){
          that.setData({
            swiperList: res.data.data.swiperList

          })
          
        }
      }
    })
  },
  
  getNavList:function(){
    let that = this
    wx.request({
      url: 'https://mockapi.eolinker.com/7b7NMB9c75d613bc39c8f16e4e03a3d4a8f951750079dc5/navList',
      success(res){
        console.log(res)
        if(res.data.code ===0){
          console.log(res.data.data.navList)
          that.setData({
            navList:res.data.data.navList,
            value:"bbb"
          })
          console.log(that.data.navList)
          console.log(that.data.value)

        }
      }
    
    }) 
   

  },
  getVideolist(){
    let that = this
    wx.request({
      url: 'https://www.fastmock.site/mock/93050931fc378580abc0df19d5abffaa/video/api.bili_video',
      success(res){
        // console.log(res)
        if(res.data.code===0){
          that.setData({
            videoList:res.data.data.archives
          })
        }
       
      }
    })
  },
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    this.getNavList();
    this.getSwiperList();
    this.getVideolist();
    var ttt = this.data.navList
    var vvv = this.data.value
    console.log(ttt)
    console.log(vvv)
    this.data.show()
 
    


    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  dianji: function () {
    var ttt = this.data.navList
    var vvv = this.data.value
    console.log(ttt)
    console.log(vvv)
    console.log(this.data.swiperList)
    console.log(this.data.videoList)
    this.data.show()
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})