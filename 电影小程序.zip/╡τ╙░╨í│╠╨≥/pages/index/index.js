Page({

  /**
   * 页面的初始数据
   */
  data: {
    nav_list: [],
    id: 0,
    name: "全部",
    movie_list: [],
    movie_list_num: [
      { "num": Math.floor(Math.random() * 10)},
      { "num": Math.floor(Math.random() * 11)},
      { "num": Math.floor(Math.random() * 12)},
      { "num": Math.floor(Math.random() * 13)},
      { "num": Math.floor(Math.random() * 14)},
      { "num": Math.floor(Math.random() * 15)},
    ],

  },
  activeNav: function(e) {
    console.log(e)
    this.setData({
      id: e.target.dataset.idd,
      name: e.target.dataset.name,
    })
    console.log(this.data.name)
    this.getMoive(this.data.name)
    // console.log(e.target.dataset.id)


  },
  getNavList() {
    var that = this
    wx.request({
      url: 'https://www.fastmock.site/mock/5e7ed145865e3d2be846c1caafedd704/wx/api/typelist',
      success(res) {
        // console.log(res.data.data.list[0].list)
        that.setData({
          nav_list: res.data.data.list[0].list
        })

      }
    })
  },
  getMoive(options) {
    console.log(options)
    var that = this
    wx.showLoading({
      title: '加载中',
    })
    if (this.data.name == "全部") {
      wx.request({
        url: 'http://tv1.rhinox.cn/dytt/data/_type_',
        success(res) {
          // console.log(res.data.data.list[0].list)
          that.setData({
            movie_list: res.data.data.list[0].list
          })
          wx.hideLoading()

        }
      })
    }else{
      wx.request({
        url: 'http://tv1.rhinox.cn/dytt/data/_type_类型_' + options,
        success(res) {
          // console.log(res.data.data.list[0].list)
          that.setData({
            movie_list: res.data.data.list[0].list
          })
          wx.hideLoading()

        }
      })

    }
    

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getNavList()
    this.getMoive()

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})