//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    name: '李四',
    gender: [{
        name: '男',
        value: '0',
        
      },
      {
        name: '女',
        value: '1',
        checked: true
      }
    ],
    skills:[
      {name:'Html',value:'html',checked:true},
      {name:'Python',value:'python'},
      {name:'Java',value:'java',checked:true},
      { name: 'C#', value: 'c#', checked: true},
    ],
    opinion:'测试..'
  },
  // //事件处理函数
  // bindViewTap: function() {
  //   wx.navigateTo({
  //     url: '../logs/logs'
  //   })
  // },
  onLoad: function (options) {
    var that = this
    wx.request({
      url: 'http://127.0.0.1:3000/',
      success:function(res){
        that.setData(res.data)
      }
    })
  },
  // getUserInfo: function(e) {
  //   console.log(e)
  //   app.globalData.userInfo = e.detail.userInfo
  //   this.setData({
  //     userInfo: e.detail.userInfo,
  //     hasUserInfo: true
  //   })
  // }
  submit: function(e) {
    wx.request({
      method: 'post',
      url: 'http://127.0.0.1:3000/',
      data: e.detail.value,
      success: function(res) {
        console.log(res)
      }
    })
  }
})